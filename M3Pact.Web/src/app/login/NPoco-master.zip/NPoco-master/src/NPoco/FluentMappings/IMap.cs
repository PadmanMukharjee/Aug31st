namespace NPoco.FluentMappings
{
    public interface IMap
    {
        TypeDefinition TypeDefinition { get; }
    }
}