﻿namespace NPoco.DatabaseTypes
{
    public class SqlServer2008DatabaseType : SqlServerDatabaseType
    {
    }
}