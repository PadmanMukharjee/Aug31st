namespace NPoco
{
    public enum VersionExceptionHandling
    {
        Ignore,
        Exception
    }
}