namespace NPoco.Tests.Common
{
    public class BaseDBTest
    {
        public IDatabase Database { get; set; }
        public TestDatabase TestDatabase { get; set; }
    }
}
