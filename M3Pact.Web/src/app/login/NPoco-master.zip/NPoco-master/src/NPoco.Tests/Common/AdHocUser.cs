﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NPoco.Tests.Common
{
    public class AdHocUser
    {
        public int UserId { get { return 999; } }
        public string Name { get; set; }
    }
}
